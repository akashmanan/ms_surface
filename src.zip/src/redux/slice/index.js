import { setUserLogin } from "./authSlice";
import { setUserDetails } from "./userDetailSlice";
import { setUserInfoInformation } from "./userInfoSlice";

export { 
    setUserLogin, 
    setUserDetails,
    setUserInfoInformation,
};
