const colors = {
  white: '#FFFFFF',
  black: '#000000',
  blue: '#0000FF',
  eyeIcon: '#808080',
  selectedRadio: '#32cd32',
  radioBorder: '#707070',
  labelText: 'rgba(27, 43, 65, 0.72)',
};

const theme = {
  colors: colors,
};

export default theme;
